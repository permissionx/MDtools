from distutils.core import setup

setup(name="MDtools", 
	version="1.0.0", 
	description="My python tools", 
	author="permissionx",
	py_modules=['MDtools.readdump','MDtools.msd'])